# AIML Club OCT — Connect — Master Documentation v2

This package extends the initial PRD, architecture, and database specification.

Files:
- 04_RBAC_PERMISSIONS.md
- 05_API_SPECIFICATION.md
- 06_DESIGN_SYSTEM.md
- 07_DOMAIN_ARCHITECTURE.md
- 08_GOOGLE_DRIVE_ARCHITECTURE.md

Brand:
AIML CLUB OCT — CONNECT
Innovate. Implement. Inspire.

Repository:
https://github.com/UmeshCode1/Connect-AiML-Club-OCT

Implementation rule:
Read the master documentation before making major architectural changes.
